// Exercise: Count total and unique items in an array
// Your task is to:
// 1. Create an array of strings.
// 2. Write code that prints the number of items in the array.
// 3. Print the number of unique items in the array.


import UIKit


let album = ["Saison 00","Saison 00"]

print(album.count)

print(Set(album).count)
